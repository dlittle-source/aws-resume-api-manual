import json
import boto3

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("resumes")

def handler(event, context):
    # Example: /resumes?id=1,2,3,4,5,6,7,8,9,10
    ids_param = event.get("queryStringParameters", {}).get("id", "124,125,126,127,128,129,130,131,132,133")
    ids = ids_param.split(",")

    keys = [{"id": id.strip()} for id in ids[:10]]

    response = dynamodb.batch_get_item(
        RequestItems={
            "resumes": {
                "Keys": keys
            }
        }
    )

    items = response["Responses"].get("resumes", [])

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(items)
    }
